import java.util.Random;
import java.util.Scanner;
public class Deliverable_2 {

	public static void main(String[] args) {
		int numberOfFlips;
		int correctCount = 0;
		int i;
		int percentage;
		String headOrTailsGuess;
		Scanner headOrTails = new Scanner(System.in);
		System.out.printf("Guess which will have more: heads or tails? ");
		headOrTailsGuess = headOrTails.next();
		
			  
			  
		  
		
		Scanner flipCount = new Scanner(System.in);
		System.out.printf("How many times shall we flip a coin? ");
		numberOfFlips = flipCount.nextInt();
	
		for(i = 0; i < numberOfFlips; i++){
		Random r = new Random();
		   int chance = r.nextInt(2);
		   if (chance == 1) {
			   System.out.println("heads");
			   switch(headOrTailsGuess) {
				case "heads":
					correctCount = ++correctCount;
				}
		   }
		   else {
			   System.out.println("tails");
			   
			   switch(headOrTailsGuess) {
				case "tails":
					correctCount = ++correctCount;
				}
		   
				  
			    }
		
		
		   }
		   
			System.out.println("Your guess, " + headOrTailsGuess + ", came up " + correctCount + " time(s).");	   
			    
			   percentage = (correctCount * 100)/ numberOfFlips;
			System.out.println("That's " + percentage + "%");
		   
		  
		   
	}
	}
		
	
	


